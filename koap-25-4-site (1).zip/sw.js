const prefix = 'koap-254-offline-';
const cacheName = prefix + 'v1';
const base = new URL(self.registration.scope);
const pathUrl = path => new URL('.' + path, base);
const assets = new Map([
  ['/', 'text/html'],
  ['/style.css', 'text/css'],
  ['/app.js', 'javascript'],
  ['/site.webmanifest', 'json'],
  ['/icon-192.png', 'image/png'],
  ['/icon-512.png', 'image/png']
]);

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const entries = await Promise.all([...assets].map(async ([path, type]) => {
      const response = await fetch(pathUrl(path), {cache: 'reload', redirect: 'error'});
      if (!response.ok || !response.headers.get('Content-Type')?.includes(type)) {
        throw new Error('Unable to cache ' + path);
      }
      return [path, response];
    }));
    const cache = await caches.open(cacheName);
    await Promise.all(entries.map(([path, response]) => cache.put(path, response)));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith(prefix) && name !== cacheName).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  const path = '/' + url.pathname.slice(base.pathname.length);
  if (!url.pathname.startsWith(base.pathname)) return;
  const isHome = event.request.mode === 'navigate' && (path === '/' || path === '/index.html');
  if (!isHome && !assets.has(path)) return;
  event.respondWith((async () => {
    const cache = await caches.open(cacheName);
    try {
      return await fetch(event.request);
    } catch {
      return (await cache.match(isHome ? '/' : path)) || Response.error();
    }
  })());
});
