const title = 'Статья 25.4 КоАП Республики Беларусь';
const discipline = 'Административно-деликтное и процессуально-исполнительное право';
const sources = [
  ['КоАП Республики Беларусь', '6 января 2021 г. № 91-З · ст. 25.4, общие положения о вине и возрасте', 'https://pravo.by/document/?guid=3871&p0=HK2100091'],
  ['ПИКоАП Республики Беларусь', '6 января 2021 г. № 92-З · гл. 4 об участниках процесса, гл. 6 о доказательствах', 'https://pravo.by/document/?guid=3871&p0=HK2100092'],
  ['Консолидированный текст КоАП', 'Ст. 25.4 · редакция по состоянию на 20 июля 2026 г.', 'https://continent-online.com/document/?doc_id=38043824&mode=p&page=16']
];
const sections = [
  ['Введение', 'Обозначьте тему, цель и место нормы в КоАП.', 'Статья 25.4 входит в главу 25 КоАП Республики Беларусь об административных правонарушениях против правосудия и деятельности органов уголовной и административной юрисдикции. Цель доклада — раскрыть четыре элемента состава правонарушения и показать, как они помогают разграничить заведомую ложь и добросовестную ошибку.'],
  ['Объект', 'Какие общественные отношения охраняет статья?', 'Непосредственный объект можно определить как общественные отношения, обеспечивающие установленный порядок административного процесса и конституционного судопроизводства в части получения достоверных сведений и правильного перевода. Искажение сведений затрудняет установление обстоятельств, а неправильный перевод нарушает точность передачи содержания процессуальной информации.'],
  ['Субъект', 'Укажите возраст и соотнесите каждое деяние с ролью лица.', 'Ответственность по статье 25.4 несёт вменяемое физическое лицо, достигшее 16 лет на момент совершения деяния. В административном процессе субъект определяется способом совершения правонарушения: свидетель или потерпевший даёт объяснение, заявитель подаёт заявление, эксперт даёт заключение, переводчик выполняет перевод. Для ложного заявления значение имеет сам факт обращения с заявлением о совершении административного правонарушения.\n\nПри конституционном судопроизводстве статья называет свидетеля, эксперта и переводчика применительно к показанию, заключению и переводу соответственно.'],
  ['Объективная сторона', 'Перечислите альтернативные действия и обозначьте момент окончания.', 'В контексте административного процесса статья охватывает заведомо ложное объяснение свидетеля или потерпевшего, заведомо ложное заявление о совершении административного правонарушения, заведомо ложное заключение эксперта и заведомо неправильный перевод, сделанный переводчиком по делу.\n\nПри конституционном судопроизводстве статья охватывает заведомо ложное показание свидетеля, заведомо ложное заключение эксперта и заведомо неправильный перевод, сделанный переводчиком. Состав формальный: по смыслу диспозиции достаточно совершения одного из указанных действий в соответствующем процессуальном контексте. Влияние ложных сведений на итоговое решение для окончания состава не требуется.'],
  ['Субъективная сторона', 'Раскройте заведомость и форму вины.', 'Для состава характерен прямой умысел. Заведомость означает, что лицо в момент действия осознаёт ложность передаваемых сведений или неправильность перевода и сознательно сообщает эти сведения, даёт заключение либо выполняет такой перевод. Добросовестное заблуждение, ошибка памяти или непреднамеренная ошибка перевода сами по себе не образуют состава статьи 25.4. Мотив и цель в диспозиции как обязательные признаки не указаны.'],
  ['Санкция и вывод', 'Назовите взыскания и сформулируйте итог доклада.', 'Статья предусматривает штраф от 10 до 30 базовых величин, общественные работы или административный арест. Взыскания перечислены альтернативно.\n\nПри разборе ситуации нужно установить конкретное действие, процессуальный контекст и роль лица, а также доказать, что лицо знало о ложности сведений или неправильности перевода. Например, если свидетель в административном процессе сознательно сообщает о событии, которого, как ему известно, не было, такое объяснение может подпадать под статью 25.4 при наличии остальных признаков состава.']
];
const key = 'koap-254-report-v1';
let drafts = sections.map(section => section[2]);
try {
  const saved = JSON.parse(localStorage.getItem(key));
  if (Array.isArray(saved) && saved.length === sections.length && saved.every(value => typeof value === 'string')) drafts = saved;
} catch {}
let selected = 0;
const byId = id => document.getElementById(id);
function element(tag, content) {
  const node = document.createElement(tag);
  node.textContent = content;
  return node;
}
function sourceLink(source) {
  const link = element('a', source[0]);
  link.href = source[2];
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  link.append(element('span', source[1]));
  return link;
}
const editing = byId('editing');
const preview = byId('preview');
const copy = byId('copy');
const next = byId('next');
const steps = sections.map((section, index) => {
  const button = element('button', section[0]);
  button.className = 'step';
  button.onclick = () => { select(index); mode(false); };
  byId('sections').append(button);
  return button;
});
function updateCount() {
  byId('count').textContent = copy.value.length.toLocaleString('ru-RU') + ' симв.';
}
function select(index) {
  selected = index;
  steps.forEach((button, position) => button.setAttribute('aria-current', String(position === index)));
  byId('sectiontitle').textContent = sections[index][0];
  byId('hint').textContent = sections[index][1];
  copy.value = drafts[index];
  next.textContent = index === sections.length - 1 ? 'Открыть предпросмотр' : 'Следующий раздел';
  updateCount();
}
function mode(show) {
  editing.hidden = show;
  preview.hidden = !show;
  byId('edit').setAttribute('aria-pressed', String(!show));
  byId('show').setAttribute('aria-pressed', String(show));
  if (!show) return;
  preview.replaceChildren(element('h2', title), element('p', discipline));
  sections.forEach((section, index) => preview.append(element('h3', section[0]), element('p', drafts[index])));
  preview.append(element('h3', 'Источники'));
  sources.forEach(source => preview.append(sourceLink(source)));
}
copy.addEventListener('input', () => {
  drafts[selected] = copy.value;
  updateCount();
  try {
    localStorage.setItem(key, JSON.stringify(drafts));
    byId('status').textContent = 'Черновик сохранён в этом браузере';
  } catch {
    byId('status').textContent = 'Автосохранение недоступно. Скачайте черновик в Word.';
  }
});
next.onclick = () => {
  if (selected === sections.length - 1) {
    mode(true);
    byId('show').focus();
  } else {
    select(selected + 1);
    copy.focus();
  }
};
byId('edit').onclick = () => mode(false);
byId('show').onclick = () => mode(true);
sources.forEach(source => byId('links').append(sourceLink(source)));
select(0);

const encoder = new TextEncoder();
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function zip(files) {
  const records = [];
  const directory = [];
  let offset = 0;
  let directorySize = 0;
  for (const [name, content] of Object.entries(files)) {
    const path = encoder.encode(name);
    const data = encoder.encode(content);
    const crc = crc32(data);
    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 0x04034b50, true);
    local.setUint16(4, 20, true);
    local.setUint16(12, 33, true);
    local.setUint32(14, crc, true);
    local.setUint32(18, data.length, true);
    local.setUint32(22, data.length, true);
    local.setUint16(26, path.length, true);
    const central = new DataView(new ArrayBuffer(46));
    central.setUint32(0, 0x02014b50, true);
    central.setUint16(4, 20, true);
    central.setUint16(6, 20, true);
    central.setUint16(14, 33, true);
    central.setUint32(16, crc, true);
    central.setUint32(20, data.length, true);
    central.setUint32(24, data.length, true);
    central.setUint16(28, path.length, true);
    central.setUint32(42, offset, true);
    records.push(local.buffer, path, data);
    directory.push(central.buffer, path);
    offset += 30 + path.length + data.length;
    directorySize += 46 + path.length;
  }
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true);
  const count = Object.keys(files).length;
  end.setUint16(8, count, true);
  end.setUint16(10, count, true);
  end.setUint32(12, directorySize, true);
  end.setUint32(16, offset, true);
  return new Blob([...records, ...directory, end.buffer], {type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});
}
const escapeXml = value => value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/g, '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'})[char]);
function paragraph(value, style = 'Normal') {
  return `<w:p><w:pPr><w:pStyle w:val="${style}"/></w:pPr><w:r><w:t xml:space="preserve">${escapeXml(value)}</w:t></w:r></w:p>`;
}
function docx() {
  const word = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  const rel = 'http://schemas.openxmlformats.org/package/2006/relationships';
  const office = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  const body = [
    paragraph('УЧЕБНЫЙ ДОКЛАД', 'Subtitle'), paragraph(title, 'Title'), paragraph(discipline, 'Subtitle'),
    ...sections.flatMap((section, index) => [paragraph(section[0], 'Heading1'), ...drafts[index].split(/\r?\n/).filter(line => line.trim()).map(line => paragraph(line))]),
    paragraph('Источники', 'Heading1'), ...sources.flatMap(source => [paragraph(source[0] + ' · ' + source[1]), paragraph(source[2])])
  ].join('');
  return zip({
    '[Content_Types].xml': '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>',
    '_rels/.rels': `<Relationships xmlns="${rel}"><Relationship Id="rId1" Type="${office}/officeDocument" Target="word/document.xml"/></Relationships>`,
    'word/_rels/document.xml.rels': `<Relationships xmlns="${rel}"><Relationship Id="rId1" Type="${office}/styles" Target="styles.xml"/></Relationships>`,
    'word/document.xml': `<w:document xmlns:w="${word}"><w:body>${body}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1417" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr></w:body></w:document>`,
    'word/styles.xml': `<w:styles xmlns:w="${word}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/><w:sz w:val="26"/><w:lang w:val="ru-RU"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:pPr><w:spacing w:after="140" w:line="330" w:lineRule="auto"/></w:pPr></w:style>${[['Title',48,'122442'],['Subtitle',26,'506477'],['Heading1',32,'087767']].map(([id,size,color]) => `<w:style w:type="paragraph" w:styleId="${id}"><w:name w:val="${id === 'Heading1' ? 'heading 1' : id}"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="180" w:after="100"/>${id === 'Heading1' ? '<w:outlineLvl w:val="0"/>' : '<w:jc w:val="center"/>'}</w:pPr><w:rPr><w:b/><w:color w:val="${color}"/><w:sz w:val="${size}"/></w:rPr></w:style>`).join('')}</w:styles>`
  });
}
document.querySelectorAll('.export').forEach(button => {
  button.onclick = () => {
    const url = URL.createObjectURL(docx());
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Доклад_Статья_25.4_КоАП_РБ.docx';
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  };
});

const offlineHelp = byId('offline-help');
const offlineStatus = byId('offline-status');
function openOfflineHelp() {
  if (location.hash === '#offline-help') offlineHelp.open = true;
}
window.addEventListener('hashchange', openOfflineHelp);
openOfflineHelp();

async function prepareOffline() {
  if (!('serviceWorker' in navigator)) {
    offlineStatus.textContent = 'В этом браузере офлайн-режим недоступен. Откройте сайт в Safari или Chrome.';
    return;
  }
  try {
    const registration = await navigator.serviceWorker.register('./sw.js');
    const worker = registration.installing || registration.waiting || registration.active;
    if (!worker) throw new Error('Service worker unavailable');
    const updateStatus = () => {
      if (worker.state === 'activated') {
        offlineStatus.textContent = 'Готово к работе офлайн';
      } else if (worker.state === 'redundant') {
        offlineStatus.textContent = 'Офлайн-копия не подготовлена. Откройте сайт снова при подключении к интернету.';
      }
    };
    worker.addEventListener('statechange', updateStatus);
    updateStatus();
  } catch {
    offlineStatus.textContent = 'Офлайн-копия недоступна. Откройте сайт снова при подключении к интернету.';
  }
}
prepareOffline();
